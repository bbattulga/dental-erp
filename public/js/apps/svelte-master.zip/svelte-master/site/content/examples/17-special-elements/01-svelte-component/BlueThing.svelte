<style>
	strong { color: blue; }
</style>

<strong>blue thing</strong>