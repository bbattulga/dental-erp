<script>
	let src = 'tutorial/image.gif';
</script>

<img>