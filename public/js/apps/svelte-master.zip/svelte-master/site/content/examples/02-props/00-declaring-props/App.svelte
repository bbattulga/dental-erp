<script>
	import Nested from './Nested.svelte';
</script>

<Nested answer={42}/>