---
question: Are there any video courses?
---

There are no official ones, but here are a couple of third-part ones that we know of.

- [Egghead](https://egghead.io/playlists/getting-started-with-svelte-3-05a8541a)
- [Udemy](https://www.udemy.com/sveltejs-the-complete-guide/)

Note that Udemy very frequently has discounts over 90%.
