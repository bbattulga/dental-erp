<script>
	let src = 'tutorial/image.gif';
	let name = 'Rick Astley';
</script>

<!-- {src} is short for src={src} -->
<img {src} alt="{name} dancing">