<style>
	/* styles goes here */
</style>

<p>This is a paragraph.</p>