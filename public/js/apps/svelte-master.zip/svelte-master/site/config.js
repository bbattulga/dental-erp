export const SLUG_PRESERVE_UNICODE = false;
export const SLUG_SEPARATOR = '_';
