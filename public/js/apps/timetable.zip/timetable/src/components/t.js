let a = '13:00';
let b = '12:00';
console.log(a<b);