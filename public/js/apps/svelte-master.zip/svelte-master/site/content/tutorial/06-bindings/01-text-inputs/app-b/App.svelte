<script>
	let name = 'world';
</script>

<input bind:value={name}>

<h1>Hello {name}!</h1>