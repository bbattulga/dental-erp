















<style type="text/css">
	.booking-container {
	font-family: sans-serif;
	margin: 0;
	width: 65%;
	height: 70%;
	display: flex;
	justify-content: center;
	align-items: center;
}
.booking-container * {
	box-sizing: border-box;
}
.inner-booking-container {
	width: 65%;
	height: 60%;
	background: lightgreen;
	border-radius: 20px;
	padding: 3% 5% 10% 5%;	
	position: relative;
}
.inner-booking-container form {
	height: 100%;
	width: 100%;
}
.inner-booking-container hr {
	opacity: 0.4;
}
.inner-form {
	display: flex;
	width: 100%;
}
.left-form {
	width: 50%;
	display: flex;
	flex-direction: column;
}
.left-form label {
	margin-top: 20px;
}
.right-form {
	width: 50%;
	display: flex;
	flex-direction: column;
	text-align: center;
	align-items: center;
	justify-content: center;
}

.left-form input{
	width: 70%;
	margin: 10px;
	padding: 20px;
	border-radius: 10px;
	border: none;
}
.detail {
	width: 100%;
}
.detail p {
	width: 40%;
	display: inline-block;
}
.detail .static-text {
	text-align: right;
	width: 50%;
}
.bottom-form {
	display: flex;
	width: 80%;
}
.bottom-form input[type=text] {
	width: 80px;
	text-align: center;
}
.bottom-form input[type=submit] {
	width: 50%;
	margin-left: auto;
}

</style>