<style>
	strong { color: green; }
</style>

<strong>green thing</strong>