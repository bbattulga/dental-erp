<style>
	strong { color: red; }
</style>

<strong>red thing</strong>